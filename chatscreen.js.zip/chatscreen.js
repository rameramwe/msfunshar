'use strict';
import React from 'react'; 
import{
  AppRegistry,
  AsyncStorage,
  Dimensions,
  Image,
  NativeModules,
  PropTypes,
  ScrollView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
  Platform,
  Modal,
  Text
} from 'react-native';
import IcoButton from 'funshare/src/components/icobutton';
import IconBadge from 'react-native-icon-badge';
import StyleVars from 'funshare/StyleVars';
import Login from './login';
import firebase from 'firebase';
import Routes from 'funshare/Routes';
import DataStore from 'funshare/DataStore';
import Actions from 'funshare/Actions';
import SharedStyles from 'funshare/SharedStyles';
import IconButton from 'funshare/src/components/icotextButton';

var deviceheight = Dimensions.get('window').height ;
const styles = StyleSheet.create({
  container: {
    flex:1,
  },
  inputContainer: {
    margin:20, 
    marginTop:10,
    marginBottom:0   
  },
  input: {
    textAlign: 'center',
    fontSize: 18,
    color: '#FF4470',
    fontWeight: 'bold',
  },
  username: {
    textAlign: 'center',
    fontSize: 23,
    fontWeight: 'bold',
  },
  profilePictureContainer: {
    flexDirection: 'row',
    alignItems: "center",
    justifyContent: "center"
  },
  btnContainer:{
    alignItems: "center",
    justifyContent: "center",
    flexDirection: 'row',
    marginBottom: 5
  },
  profilePicture: {
    width: 140,
    height: 140,
    borderRadius: 70,
    marginBottom: 5,
  },
  footer: {
    bottom: 0,
    left: 0,
    right: 0,
    height: 48,
    alignItems: "center",
    marginTop:37,
    paddingVertical: 15,
    backgroundColor: "rgba(255,255,255,0.1)",
    borderTopWidth: 1,
    borderTopColor: "rgba(255,255,255,0.5)"
  },
  footerText: {
    color: "white",
    fontSize: 14
  },
  IContainer:{
    alignItems:'flex-start',
    padding:3,
    backgroundColor: "rgba(255,255,255,0.1)",
  },
  image:{
    height:60,
    width:60,
    borderRadius:30
  }
});

class chatscreen extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
     animationType: 'fade',
     modalVisible: false,
     transparent: true,
   };
 }


 goToHome()
 {
  this.props.replaceRoute(Routes.Home());
}

_setModalVisible = (visible) => {
  this.setState({modalVisible: visible});
}

render() {
 const TopNavigation = () => (
  <View style={{ padding: 10, flexDirection: 'row', backgroundColor: '#FF5C7E' }}>


  <View style={{ flex:0.4 , alignItems:'flex-start', justifyContent:'center' , margin:5  }}>
  <IcoButton

  source={require('funshare/src/img/swop.png')}
  onPress={this.goToHome.bind(this)}
  icostyle={{width:35, height:35}}
  />
  </View>
  <View style={{ flex:0.2 , alignItems:'center', justifyContent:'center'   }}>
  <IcoButton
  source={require('funshare/src/img/f.png')}
  icostyle={{width:45, height:45}}
  />
  </View>

  <View style={{ flex:0.4 , justifyContent:'center' , margin:5  }}>
  </View>
  </View>
  );
 return (
  <View style = {styles.container}>  
  <TopNavigation/>  
  <ScrollView>
  <View style ={{flex:2,flexDirection:'row',  alignItems:'center',
  justifyContent:'center'
}}>

<Modal
animationType={this.state.animationType}
transparent={this.state.transparent}
visible={this.state.modalVisible}
onRequestClose={() => {this._setModalVisible(false)}}
>

<View style={ {flex:1} }>

<View style= {{ height:deviceheight, backgroundColor:   'rgba(0, 0, 0, 0.9)'}} >
<View style= {{alignItems:'center'}} >
<Text style={{color:'white', fontSize:40,fontWeight:'bold',marginTop:25}}>Glückwunsch</Text>
<Text style={{color:'white', fontSize:30,fontWeight:'bold',marginTop:25}}>it's a Deal!</Text>
</View>

<View style = {{alignItems:'center' , marginTop:25}}>
<Image 
resizeMode={Image.resizeMode.contain}
source={require('../img/Logo.png')}
style={{height:40, width:40}}                                
/>

</View>


<View style = {{flexDirection:'row', flex:1 ,justifyContent:'center' }}>
<View style = {{  flex:0.5 ,alignItems:'center' }}>
<Image  
source={require('../img/user.jpg')}
style={{height:100 , width:100 , borderRadius:50}}                                
/>
</View>
<View style = {{  flex:0.5 ,alignItems:'center' }}>
<Image 
 
source={require('../img/user.jpg')}
style={{height:100 , width:100 , borderRadius:50}}                                
/>
</View>
</View>
<View style={{position:'absolute', bottom:30 ,flex:1,marginLeft:20,marginRight:20,flexDirection:'row',alignItems:'center', justifyContent:'center'}}>



<View style={{flexDirection:'row',flex:0.5 }}>
<Text style={{color:'white', fontSize:15 ,marginTop:18  }}>Abbrechen</Text>
<IcoButton
onPress={this._setModalVisible.bind(this, false)}
source={require('funshare/src/img/dislike.png')}
icostyle={{width:60, height:60}}
/>
</View>

<View style={{flexDirection:'row',flex:0.5 }}>

<IcoButton
source={require('funshare/src/img/like.png')}
//onPress={this.props._setModalVisible}
icostyle={{width:60, height:60}}
/>
<Text style={{color:'white', fontSize:15 ,marginTop:18  }}>Bestätigen</Text>
</View>



</View>

</View>
</View>
</Modal>



<View style={{flex:1}}>

<View style = {{flex:1,paddingTop:8, paddingBottom:12, paddingLeft:20, flexDirection:'row' ,backgroundColor:'white'}} >

<View style = {{flex:0.6 , flexDirection:'row', justifyContent:'flex-start' , alignItems:'center'}}>
<Image
style={ styles.image }
source={require('funshare/src/img/ichat.png')}
/> 
<Image
style={{height:25 , width : 25 , margin:10}}
source={require('funshare/src/img/star.png')}
/> 
<Image
style={ styles.image }
source={require('funshare/src/img/ichat.png')}
/> 
</View>

<View style = {{flex:0.4 , flexDirection:'row', justifyContent:'center'}}>
<TouchableOpacity
style = {{flex:0.5 , justifyContent:'center' , alignItems:'center'}}
  //onPress={}
  >
  <View>
  <Image
  style={{height:40 , width:40}}
  source={require('funshare/src/img/dislike.png')}
  /> 
  </View>
  </TouchableOpacity>

  <TouchableOpacity
  style = {{flex:0.5 , justifyContent:'center' , alignItems:'center'}}
  onPress={this._setModalVisible.bind(this, true)}
  >
  <View>
  <Image
  style={{height:40 , width:40}}
  source={require('funshare/src/img/like.png')}
  /> 
  </View>
  </TouchableOpacity>

  </View>

  </View>
  </View>


  </View>

  </ScrollView>
  </View>

  );
}

}


export default chatscreen;